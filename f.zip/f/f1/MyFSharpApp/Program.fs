﻿type Coach = {
    Nme: string
    Player: bool
}
type Stats = {
    Wins: int
    Loss: int
}
type Team = {
    Nme: string
    Coach: Coach
    Stats: Stats
}

let coach1 = { Nme = "Mike Brown"; Player = false }
let coach2 = { Nme = "Gregg Popovich"; Player = false }
let coach3 = { Nme = "Darko Rajakovic"; Player = false }
let coach4 = { Nme = "Will Hardy"; Player = false }
let coach5 = { Nme = "Brian Keefe"; Player = false }

let stats1 = { Wins = 46; Loss = 36 }
let stats2 = { Wins = 22; Loss = 60 }
let stats3 = { Wins = 25; Loss = 57 }
let stats4 = { Wins = 31; Loss = 51 }
let stats5 = { Wins = 8; Loss = 32 }

let team1 = { Nme = "Sacramento Kings"; Coach = coach1; Stats = stats1 }
let team2 = { Nme = "San Antonio Spurs"; Coach = coach2; Stats = stats2 }
let team3 = { Nme = "Toronto Raptors"; Coach = coach3; Stats = stats3 }
let team4 = { Nme = "Utah Jazz"; Coach = coach4; Stats = stats4 }
let team5 = { Nme = "Washington Wizards"; Coach = coach5; Stats = stats5 }

let teams = [team1; team2; team3; team4; team5]
teams |> List.iter (fun team -> printfn "Team: %s, Coach: %s, Wins: %d, Loss: %d" team.Nme team.Coach.Nme team.Stats.Wins team.Stats.Loss)

let isSuccessful team =
    team.Stats.Wins > team.Stats.Loss
let successfulTeams = teams |> List.filter isSuccessful
successfulTeams |> List.iter (fun team ->
    printfn "Successful Team: %s, Coach: %s, Wins: %d, Loss: %d" 
        team.Nme 
        team.Coach.Nme 
        team.Stats.Wins 
        team.Stats.Loss
)

let calculateSuccessPercentage team =
    let totalGames = float (team.Stats.Wins + team.Stats.Loss)
    let successPercentage = (float team.Stats.Wins / totalGames) * 100.0
    (team.Nme, successPercentage)
let successPercentages = teams |> List.map calculateSuccessPercentage
successPercentages |> List.iter (fun (teamName, percentage) ->
    printfn "Team: %s, Success Percentage: %.2f%%" teamName percentage
)